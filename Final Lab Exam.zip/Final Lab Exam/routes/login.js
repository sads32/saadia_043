const express = require('express');
const router = express.Router();

// Handle form submission
router.post('/login', async(req, res) => {
 
  console.log("I am in Login route")
  res.redirect('/dashboard');
});

module.exports = router;
