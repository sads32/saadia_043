// Add event listeners to the edit buttons
const editBtns = document.getElementsByClassName('edit-btn');
Array.from(editBtns).forEach(btn => {
  btn.addEventListener('click', function() {
    const cardBody = this.parentElement;
    const editForm = cardBody.querySelector('.edit-form');
    editForm.classList.toggle('d-none');
  });
});

// Add event listener to the add game button
const addGameBtn = document.getElementById('addGameBtn');
addGameBtn.addEventListener('click', function() {
  const addGameForm = document.getElementsByClassName('add-game-form')[0];
  addGameForm.classList.toggle('d-none');
});

// Add event listeners to the delete buttons
const deleteBtns = document.getElementsByClassName('delete-btn');
Array.from(deleteBtns).forEach(btn => {
  btn.addEventListener('click', async function() {
    const deleteForm = this.parentElement;
    const gameId = deleteForm.closest('.card').dataset.gameId;
    const confirmation = confirm('Are you sure you want to delete this blog?');
    if (confirmation) {
      try {
        const response = await fetch(`/games/${gameId}`, {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json'
          }
        });
        if (!response.ok) {
          throw new Error('Failed to delete blog');
        }
        location.reload(); // Reload the page after successful deletion
      } catch (error) {
        console.error(error);
        alert('Failed to delete blog');
      }
    }
  });
});

// Function to update a game
const updateGame = async (gameId, updatedtitle, updatedcontent) => {
  try {
    const response = await fetch(`/games/${gameId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        title: updatedtitle,
        content: updatedcontent
      })
    });
    if (!response.ok) {
      throw new Error('Failed to update game');
    }
    const data = await response.json();
    console.log(data.message);
    // Update the game details in the UI
    const gameCard = document.querySelector(`.card[data-game-id="${gameId}"]`);
    if (gameCard) {
      const cardTitle = gameCard.querySelector('.card-title');
      const cardPrice = gameCard.querySelector('.card-text');
      cardTitle.textContent = updatedtitle;
      cardPrice.textContent = `Price: ${updatedcontent}`;
      gameCard.querySelector('.edit-form').classList.add('d-none');
    }
  } catch (error) {
    console.error(error);
  }
};

const saveBtns = document.querySelectorAll('.save-btn');
saveBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    const gameCard = btn.closest('.card');
    const gameId = gameCard.dataset.gameId;
    const editTitle = gameCard.querySelector('#editTitle').value;
    const editContent = gameCard.querySelector('#editContent').value;
    updateGame(gameId, editTitle, editContent);
  });
});